# -*- coding: utf-8 -*-
# Author: Damien Crier
# Author: Julien Coux
# Copyright 2016 Camptocamp SA
# License AGPL-3.0 or later (http://www.gnu.org/licenses/agpl.html).
from . import aged_partner_balance_wizard
from . import general_ledger_wizard
from . import journal_report_wizard
from . import open_items_wizard
from . import trial_balance_wizard
