10.0.3.1.0 (2019-04-26)
~~~~~~~~~~~~~~~~~~~~~~~

* In the Trial Balance you have an option to hide parent hierarchy levels


10.0.3.0.0 (2019-01-09)
~~~~~~~~~~~~~~~~~~~~~~~

* Improve multicompany related usability.
* Improve performance in the General Ledger.
* The reports now display an improved title that includes report name,
  company and currency.


10.0.2.0.0 (2018-11-29)
~~~~~~~~~~~~~~~~~~~~~~~

* The Trial Balance now allows to display the hierarchy of accounts
* In the Trial Balance you can apply a filter by hierarchy levels
* The Trial Balance shows the unaffected earnings account computed as:
  initial balance: sum of past unaffected earnings + P&L result; debit, credit
  and period balance: totals only for the unaffected earnings account.
* In the Journal Ledger the field 'Journal' is now optional
